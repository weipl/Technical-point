package com.jt.manage.service;

import java.util.List;

import com.jt.common.vo.EasyUIResult;
import com.jt.manage.pojo.Item;

public interface ItemService {

	List<Item> findItemAll();

	EasyUIResult findItemByPage(Integer page, Integer rows);

	void saveItem(Item item);

	void updateItem(Item item);

	void deleteItems(Long[] ids);

	void updateStatus(int status, Long[] ids);
	
	


}
